<?php

namespace slc\Controllers;

use Monolog\Logger;
use slc\Controllers\BaseController;
use slc\Models\Users;
use slc\System\SendEmail;

session_start();

class Main extends BaseController
{

    public function index($data = [])
    {



        // Recupera os dados do sensor do banco de dados
        $model = new Users();
        $data_sensor = $model->get_datasensor_user(1);
        $data['sensor'] = $data_sensor;
        $_SESSION['sensor'] = $data['sensor'];


        $this->view('layouts/html_header');
        $this->view('navbar');
        $this->view('grafico', $data);
        $this->view('status', $data);
        $this->view('footer');
        $this->view('layouts/html_footer');
    }



    public function get_sensor_data()
    {

        $id = 1;
        $model = new Users();
        $data_sensor = $model->get_datasensor_user($id);
        echo json_encode($data_sensor);
    }


    public function get_sensor_data_grafic()
    {
        $id = 1;
        $model = new Users();
        $data_sensor = $model->get_datasensor_grafic($id);
        echo json_encode($data_sensor);
    }

    // public function salvar_dados($temperatura, $umidade_ar, $umidade_solo)
    // {

    //     // Verifica se os dados necessários foram enviados
    //     if (isset($_POST['temperatura'], $_POST['umidade_ar'], $_POST['umidade_solo'])) {
    //         // Captura os dados da requisição POST
    //         $user_id = 1; // ID do usuário
    //         $temperatura = floatval($_POST['temperatura']);
    //         $umidade_ar = intval($_POST['umidade_ar']);
    //         $umidade_solo = intval($_POST['umidade_solo']);
    //         $recorded_at = date('Y-m-d H:i:s'); // Captura o timestamp atual

    //         $model = new Users();
    //         $save_data = $model->save_datasensor($user_id, $temperatura, $umidade_ar, $umidade_solo, $recorded_at);
    //         if ($save_data) {
    //             echo json_encode(["status" => "success", "message" => "Dados salvos com sucesso!"]);
    //         } else {
    //             echo json_encode(["status" => "error", "message" => "Erro ao salvar os dados!"]);
    //         }
    //     } else {
    //         echo json_encode(["status" => "error", "message" => "Dados incompletos!"]);
    //     }
        
    // }

    

}
