<p class="title-dados">Gráfico</p>

<div id="columnchart_material" class="grafico"></div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
  google.charts.load('current', {
    'packages': ['corechart', 'bar']
  });

  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
  $.ajax({
    url: '/SLC02/SLC02/public/?ct=main&mt=get_sensor_data_grafic', // URL do endpoint
    method: 'GET',
    success: function(data) {
      console.log('Dados recebidos:', data); // Log para depuração
      var sensorData = JSON.parse(data);
        var chartData = [['Hora', 'Temperatura', 'Umidade do Ar', 'Umidade do Solo']];

        sensorData.results.forEach(function(dado) {
          // Converte o horário para formato de 12 horas com AM/PM
          const periodStart = new Date(dado.period_start).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
          });

          chartData.push([
            periodStart, // Exibe o horário no formato 12 horas
            parseFloat(parseFloat(dado.avg_temperatura).toFixed(1)), // Temperatura
            parseFloat(parseFloat(dado.avg_umidade_ar).toFixed(1)),  // Umidade do ar
            parseFloat(parseFloat(dado.avg_umidade_solo).toFixed(1)) // Umidade do solo
          ]);
        });

        console.log('Dados do gráfico:', chartData); // Log para depuração

        var data = google.visualization.arrayToDataTable(chartData);

      // Obtendo a data atual no formato dia/mês/ano
      var today = new Date();
      var formattedDate = today.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });

      var options = {
        title: 'Média dos dados a cada 2 horas - ' + formattedDate, // Adiciona a data ao título
        legend: {
          position: 'none'
        },
        chartArea: {
          width: '80%',
          height: '70%'
        }
      };

      const screenWidth = window.innerWidth;
      let chart;

      if (screenWidth <= 720) {
        chart = new google.visualization.BarChart(document.getElementById('columnchart_material'));
        options.bars = 'horizontal';
        options.vAxis = {
          textPosition: 'out'
        };
      } else {
        chart = new google.visualization.ColumnChart(document.getElementById('columnchart_material'));
      }

      chart.draw(data, options);
    },
    error: function() {
      console.error('Erro ao obter os dados do sensor');
    }
  });
}


  window.addEventListener('resize', drawChart);
</script>

<div class="rotulos">
  <div class="rotulo-cores">
    <img src="assets/img/azul.png" alt="">
    <p>Umidade do Ar </p>
  </div>

  <div class="rotulo-cores">
    <img src="assets/img/vermelho.png" alt="">
    <p>Umidade do Solo</p>
  </div>

  <div class="rotulo-cores">
    <img src="assets/img/laranja.png" alt="">
    <p>Temperatura</p>
  </div>
</div>