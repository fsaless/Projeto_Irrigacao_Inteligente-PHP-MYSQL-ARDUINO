<header class="headerConteiner">
    <div class="headerContent">
        <a href="http://localhost/SLC02/SLC02/public/">
            <img src="assets/img/logo-slc.png" alt="" srcset="">
        </a>

       
    </div>
</header>