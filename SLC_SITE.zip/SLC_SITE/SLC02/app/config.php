<?php

define('APP_NAME', 'SLC Ardu');

 
// database
define('MYSQL_HOST',        'srv1937.hstgr.io');
define('MYSQL_DATABASE',    'u378591610_nova'); 
// define('MYSQL_USERNAME',    'user_projeto_arduino');
define('MYSQL_USERNAME',    'u378591610_nova');
define('MYSQL_PASSWORD',    '@Pardu10');
// define('MYSQL_PASSWORD',    '3LduNkJe55lVk0iaQRXvV0j1tZpA7OW5');

define('MYSQL_AES_KEY',     'Vduu47qL51hLn6bkYkY6NlO1nivsmdfD');

//logs
define('LOG_PATH',  __DIR__ . '/../logs/app.log');

//openssl
define('OPENSSL_KEY', 'H0SDRQzIGqcLx2kbYBK9xspdn9U5t5Wa');
define('OPENSSL_IV', 'BzKAbjUREsHgnw5d');


// define('EMAIL_HOST', 'sandbox.smtp.mailtrap.io');
// define('EMAIL_PORT', '2525');
// define('EMAIL_USERNAME',  '198bb5d13d414c');
// define('EMAIL_PASSWORD', '17e7fd0f753761'); // Use a senha correta para o Yahoo
// define('EMAIL_FROM', 'slcardu@slcardu.com');

