<div class="footer">
    <div class="text-footer">
        <p>
            © 2024 SLC ARDU.
        </p>
    </div>

    <!-- <div class="text-footer">
        <a href="#">
            Suporte
        </a>
    </div> -->





</div>