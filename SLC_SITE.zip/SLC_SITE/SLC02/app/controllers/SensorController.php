<?php

namespace slc\Controllers;

use slc\Models\Users;

class SensorController extends BaseController
{
    public function index()
    {
        // Verifica se os dados necessários foram enviados
        if (isset($_POST['temperatura'], $_POST['umidade_ar'], $_POST['umidade_solo'])) {
            // Captura os dados da requisição POST
            $user_id = 1; // ID do usuário
            $temperatura = floatval($_POST['temperatura']);
            $umidade_ar = intval($_POST['umidade_ar']);
            $umidade_solo = intval($_POST['umidade_solo']);
            $recorded_at = date('Y-m-d H:i:s'); // Captura o timestamp atual

            $model = new Users();
            $save_data = $model->save_datasensor($user_id, $temperatura, $umidade_ar, $umidade_solo, $recorded_at);
            if ($save_data) {
                echo json_encode(["status" => "success", "message" => "Dados salvos com sucesso!"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao salvar os dados!"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Dados incompletos!"]);
        }
    }
}