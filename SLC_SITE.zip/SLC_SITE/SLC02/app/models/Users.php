<?php

namespace slc\Models;

use slc\Models\BaseModel;

class Users extends BaseModel

{

    //BUSCAR OS DADOS DOS SENSORES PELO ID SO USER
    public function get_datasensor_user($id)
    {
        $params = [
            ':user_id' => $id // Alinhando o nome do parâmetro
        ];

        $this->db_connect(); // Estabelece a conexão com o banco de dados
        $results = $this->query("SELECT * FROM datasensors WHERE user_id = :user_id ORDER BY recorded_at DESC LIMIT 1", $params);

        // Se quiser, pode verificar o resultado antes de retornar
        if ($results) {
            return $results; // Retorna os dados encontrados
        } else {
            return []; // Retorna um array vazio caso não haja resultados
        }
    }

    public function get_datasensor_grafic($id)
    {
        $params = [
            ':user_id' => $id
        ];

        $this->db_connect(); // Estabelece a conexão com o banco de dados

        // Consulta para obter a média dos dados em intervalos de duas horas
        $query = "
            SELECT 
                CONCAT(DATE_FORMAT(recorded_at, '%Y-%m-%d '), 
                       LPAD(FLOOR(HOUR(recorded_at) / 2) * 2, 2, '0'), ':00:00') as period_start,
                AVG(temperatura) as avg_temperatura,
                AVG(umidade_ar) as avg_umidade_ar,
                AVG(umidade_solo) as avg_umidade_solo
            FROM datasensors
            WHERE user_id = :user_id
            GROUP BY period_start
            ORDER BY period_start
        ";

        $results = $this->query($query, $params);


        if ($results) {
            return $results; // Retorna os dados encontrados
        } else {
            return []; // Retorna um array vazio caso não haja resultados
        }
    }

    // public function save_datasensor($user_id, $temperatura, $umidade_ar, $umidade_solo, $recorded_at)
    // {
    //     $params = [
    //         ":user_id" => $user_id,
    //         ":temperatura" => $temperatura,
    //         ":umidade_ar" => $umidade_ar,
    //         ":umidade_solo" => $umidade_solo,
    //         ":recorded_at" => $recorded_at
    //     ];

    //     $this->db_connect();
    //     $results = $this->query("INSERT INTO datasensors (user_id, temperatura, umidade_ar, umidade_solo, recorded_at) VALUES (:user_id, :temperatura, :umidade_ar, :umidade_solo, :recorded_at)", $params);

    //     if ($results) {
    //         return $results; // Retorna os dados encontrados
    //     } else {
    //         return []; // Retorna um array vazio caso não haja resultados
    //     }
    // }
}
