<!DOCTYPE html>
<html lang="pt-br">

<head>

<!-- 
‹meta name="apple-mobile-web-app-capable" content="yes">
‹meta name="apple-mobile-web-app-status-bar-style" content="black">
‹meta name="apple-mobile-web-app-title" content="edson iOS">
dink rel="apple-touch-icon" href="images/icons/icon-152x152.png">
«ink rel="manifest" href="manifest.json" /> -->


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acompanhamento Gráfico</title>
    <meta name="theme-color" content="#f9f9f9">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="edson iOS">
    <link rel="apple-touch-icon" href="assets/img/favicon_logo.png">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="/manifest.json">
    <link rel="icon" href="assets/img/favicon_logo.png" type="image/x-icon">
    <!-- <link rel="canonical" href="https://www.slcagricola.com.br/"> -->
    <link rel="canonical" href="https://a13e-170-254-248-0.ngrok-free.app/SLC02/SLC02/public/">
    
    

</head>

<body>

<script>
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
    .then(registration => {
        console.log('Service Worker registrado com sucesso:', registration);
    })
    .catch(error => {
        console.log('Falha ao registrar o Service Worker:', error);
    });
}
</script>