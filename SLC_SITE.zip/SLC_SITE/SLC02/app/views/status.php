<!-- Div onde a mensagem será exibida -->
<div id="alerta-irrigacao"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        function updateSensorData() {
            $.ajax({
                url: '/SLC02/SLC02/public/?ct=main&mt=get_sensor_data', // URL do endpoint
                method: 'GET',
                success: function(data) {
                    console.log('Dados recebidos:', data); // Adiciona log para depuração
                    var sensorData = JSON.parse(data);
                    if (sensorData.results && sensorData.results.length > 0) {
                        var dado = sensorData.results[0];
                        $('#temperatura').text(Math.round(dado.temperatura) + ' °C');
                        $('#umidade_solo').text(dado.umidade_solo + ' %');
                        $('#umidade_ar').text(dado.umidade_ar + ' %');

                        // Verifica a umidade do solo e exibe alerta
                        var umidade_solo = dado.umidade_solo;
                        var alertaHtml = '';

                        if (umidade_solo <= 50) {
                            alertaHtml = `
                                <div class="alert alert-success p-2 text-center mt-5 alerta-custom">  
                                    <div>Irrigando!!! Umidade do solo menor ou igual a 50%</div>
                                </div>
                            `;
                        } else {
                            var alertaHtml = `
                                 <div class="alert alert-danger p-2 text-center mt-5 alerta-custom">
                                     <div>Irrigação desativada!!!</div>
                                 </div>
                            `;

                        }

                        // Insere o alerta na página
                        $('#alerta-irrigacao').html(alertaHtml);

                    } else {
                        $('#temperatura').text('Dados não disponíveis');
                        $('#umidade_solo').text('Dados não disponíveis');
                        $('#umidade_ar').text('Dados não disponíveis');
                    }
                },
                error: function() {
                    console.error('Erro ao obter os dados do sensor');
                }
            });
        }

        // Atualiza os dados a cada 5 segundos
        setInterval(updateSensorData, 15000);

        // Atualiza os dados imediatamente ao carregar a página
        updateSensorData();
    });
</script>



<p class="title-dados">Status Atual</p>


<section class="status">

    <div class="status-cards">
        <div class="cards">
            <p class="text-card"><span class="text-span">Temperatura Atual: <span id="temperatura" style="font-weight: bold;">Carregando...</span> </span> </p>
        </div>


        <div class="cards">
            <p class="text-card"> <span class="text-span">Umidade do Ar Atual: <span id="umidade_ar" style="font-weight: bold;">Carregando...</span></span></p>
        </div>

        <div class="cards">
            <p class="text-card"> <span class="text-span">Umidade do Solo Atual: <span id="umidade_solo" style="font-weight: bold;">Carregando...</span></span></p>
        </div>


    </div>
</section>

<!-- <p class="title-descption">A Irrigação ocorre quando a Umidade do Solo alcança 50%</p> -->