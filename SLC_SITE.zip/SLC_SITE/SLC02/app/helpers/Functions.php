<?php

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

function check_session()
{
    return isset ($_SESSION['user']);
}

function printData($data, $die = true){
    
    echo 'pre';

    if(is_object($data) || is_array($data)){
        print_r($data);
    } else {
        echo $data;
    }
    if($die){
        echo '<br>FIM</br>';
    }
}

