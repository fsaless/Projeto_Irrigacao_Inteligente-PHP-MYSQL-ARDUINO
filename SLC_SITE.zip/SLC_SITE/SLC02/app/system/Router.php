<?php

namespace slc\System;
use slc\Controllers\Main;
use Exception;

class Router
{
    public static function dispatch()
    {
        // Valores padrão
        $httpverb = $_SERVER['REQUEST_METHOD'];
        $controller = 'main';
        $method = 'index';

        // Verifica parâmetros de URI
        if (isset($_GET['ct'])) {
            $controller = $_GET['ct'];
        }

        if (isset($_GET['mt'])) {
            $method = $_GET['mt'];
        }

        // Obtém parâmetros
        $parameters = $_GET;

        // Remove parâmetros do controller e método
        if (key_exists('ct', $parameters)) {
            unset($parameters['ct']);
        }

        if (key_exists('mt', $parameters)) {
            unset($parameters['mt']);
        }

        // Tenta instanciar o controlador e executar o método
        try {
            $class = "slc\Controllers\\" . ucfirst($controller);
            $controller = new $class();
            if (method_exists($controller, $method)) {
                $controller->$method(...$parameters);
            } else {
                die("Método $method não encontrado no controlador $class.");
            }
        } catch (Exception $err) {
            die($err->getMessage());
        }
    }
}